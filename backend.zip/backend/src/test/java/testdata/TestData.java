package testdata;

import java.math.BigDecimal;
import model.Record;
/**
 * This class will use as a test data preparation purpose, it holds test constant as well
 * @author 472634
 *
 */
public class TestData {
  public static final String DUPLICATE_REFERENCE_NUMBER_DETECTED =
      "Duplicate Reference Number detected: 12345 and Description: TEST DESCRIPTION";
  public static final String ALL_REFERENCE_ARE_UNIQUE = "All Reference are unique ";
  public static final String WRONG_END_BALANCE_FORMAT =
      "Wrong End Balance format: 9000.899999 Reference Number: 12345 and Description: TEST DESCRIPTION";
  public static final String END_BALANCE_FORMAT_IS_CORRECT = "End balance format is correct";
  public static final String END_BALANCE_NOT_MATCHING =
      "End Balance not matching for Reference Number: 12345 and Description: TEST DESCRIPTION";
  public static final String END_BALANCE_CALCULATION_IS_CORRECT = "End balance calculation is correct";

  public static final Integer REFERENCE_TEST = 12345;

  public static final String ACCOUNT_NUMBER_TEST = "NL74ABNA0248990274";
  public static final String DESC_TEST = "TEST DESCRIPTION";
  public static final BigDecimal START_BAL_TEST = BigDecimal.valueOf(1000.00);
  public static final BigDecimal MUTATION_TEST = BigDecimal.valueOf(+1000.00);
  public static final BigDecimal END_BAL_CORRECT_TEST = BigDecimal.valueOf(2000.00);
  public static final BigDecimal END_BAL_INCORRECT_TEST = BigDecimal.valueOf(9000.00);
  public static final BigDecimal END_BAL_INCORRECT_FORMAT_TEST = BigDecimal.valueOf(9000.899999);


  public static class RecordBuilder {

    private Integer reference = REFERENCE_TEST;
    private String accountNumber = ACCOUNT_NUMBER_TEST;
    private String description = DESC_TEST;
    private BigDecimal startBalance = START_BAL_TEST;
    private BigDecimal mutation = MUTATION_TEST;
    private BigDecimal endBalance = END_BAL_CORRECT_TEST;

    public RecordBuilder withReference(int reference) {
      this.reference = reference;
      return this;
    }

    public RecordBuilder withAccountNumber(String accountNumber) {
      this.accountNumber = accountNumber;
      return this;
    }

    public RecordBuilder withDescription(String description) {
      this.description = description;
      return this;
    }

    public RecordBuilder withStartBalance(BigDecimal startBalance) {
      this.startBalance = startBalance;
      return this;
    }

    public RecordBuilder withMutation(BigDecimal mutation) {
      this.mutation = mutation;
      return this;
    }

    public RecordBuilder withEndBalance(BigDecimal endBalance) {
      this.endBalance = endBalance;
      return this;
    }

    public Record build() {
      Record newRecord = new Record();
      newRecord.setAccountNumber(accountNumber);
      newRecord.setDescription(description);
      newRecord.setEndBalance(endBalance);
      newRecord.setMutation(mutation);
      newRecord.setReference(reference);
      newRecord.setStartBalance(startBalance);
      return newRecord;
    }
  }
}
