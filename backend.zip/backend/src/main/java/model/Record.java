package model;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class is represent the record object, and contains its attributes
 * 
 * @author 472634
 *
 */
@XmlRootElement(name = "record")
@XmlAccessorType(XmlAccessType.FIELD)
public class Record {
  @XmlAttribute(name = "reference")
  private Integer reference;
  @XmlElement(name = "accountNumber")
  private String accountNumber;
  @XmlElement(name = "description")
  private String description;
  @XmlElement(name = "startBalance")
  private BigDecimal startBalance;
  @XmlElement(name = "mutation")
  private BigDecimal mutation;
  @XmlElement(name = "endBalance")
  private BigDecimal endBalance;

  public Record() {}

  public Record(Integer reference, String accountNumber, String description, BigDecimal startBalance, BigDecimal mutation,
      BigDecimal endBalance) {
    this.reference = reference;
    this.accountNumber = accountNumber;
    this.description = description;
    this.startBalance = startBalance;
    this.mutation = mutation;
    this.endBalance = endBalance;
  }

  public Record(String[] each) {
    this.reference = Integer.valueOf(each[0]);
    this.accountNumber = each[1];
    this.description = each[2];
    this.startBalance = BigDecimal.valueOf(Double.valueOf(each[3]));
    this.mutation = BigDecimal.valueOf(Double.valueOf(each[4]));
    this.endBalance = BigDecimal.valueOf(Double.valueOf(each[5]));
  }

  public Integer getReference() {
    return reference;
  }

  public void setReference(Integer reference) {
    this.reference = reference;
  }

  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public BigDecimal getStartBalance() {
    return startBalance;
  }

  public void setStartBalance(BigDecimal startBalance) {
    this.startBalance = startBalance;
  }

  public BigDecimal getMutation() {
    return mutation;
  }

  public void setMutation(BigDecimal mutation) {
    this.mutation = mutation;
  }

  public BigDecimal getEndBalance() {
    return endBalance;
  }

  public void setEndBalance(BigDecimal endBalance) {
    this.endBalance = endBalance;
  }

}
