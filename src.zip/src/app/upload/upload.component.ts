import { Component, ViewChild, OnInit, AfterViewInit } from '@angular/core';
import { MatTableDataSource, MatSort } from '@angular/material';


@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit, AfterViewInit {

  public csvRecords: any[] = [];
  public displayedColumns = ['firstName', 'surname', 'issueCount', 'dateOfBirth'];
  public dataSource = new MatTableDataSource<CSVRecord>();
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('fileImportInput') fileImportInput: any;
  AppComponent() { };
  ngOnInit() {
    this.dataSource.filterPredicate =
      (data: CSVRecord, filtersJson: string) => {
        const matchFilter = [];
        const filters = JSON.parse(filtersJson);

        filters.forEach(filter => {
          const val = data[filter.id] === null ? '' : data[filter.id];
          matchFilter.push(val.toLowerCase().includes(filter.value.toLowerCase()));
        });
        return matchFilter.every(Boolean);
      };
  }
  applyFilter(filterValue: string) {
    const tableFilters = [];
    tableFilters.push({
      id: 'issueCount',
      value: filterValue
    });
    this.dataSource.filter = JSON.stringify(tableFilters);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
  }

  changeListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    if (this.isCSVFile(files[0])) {
      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);
        let headersRow = this.getHeader(csvRecordsArray);
        this.csvRecords = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        this.dataSource.data = this.csvRecords;
      };
      reader.onerror = function () {
        alert('Unable to read ' + input.files[0]);
      };
    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let dataArr = [];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let data = (<string>csvRecordsArray[i]).split(',');
      if (data.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();

        if (data[0].trim().includes('"')) {
          csvRecord.firstName = data[0].substr(1).slice(0, -1);
        } else {
          csvRecord.firstName = data[0].trim();
        }
        if (data[0].trim().includes('"')) {
          csvRecord.surname = data[1].substr(1).slice(0, -1);
        } else {
          csvRecord.surname = data[1].trim();
        }
        csvRecord.issueCount = data[2].trim();
        if (data[3].trim().includes('"')) {
          csvRecord.dob = data[3].substr(1).slice(0, -1);
        } else {
          csvRecord.dob = data[3].trim();
        }
        dataArr.push(csvRecord);
      }
    }
    return dataArr;
  }

  isCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeader(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = [];
  }

}

export class CSVRecord {
  public firstName: any;
  public surname: any;
  public issueCount: any;
  public dob: any;
  constructor() {
  }

}
