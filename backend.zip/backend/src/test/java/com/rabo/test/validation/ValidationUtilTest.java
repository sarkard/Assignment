package com.rabo.test.validation;


import static org.junit.Assert.assertEquals;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import model.Record;
import testdata.TestData;
import validation.ValidationUtil;

public class ValidationUtilTest {
  private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
  private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
  private final PrintStream originalOut = System.out;
  private final PrintStream originalErr = System.err;

  @Before
  public void setUpStreams() {
    System.setOut(new PrintStream(outContent));
    System.setErr(new PrintStream(errContent));
  }

  @After
  public void restoreStreams() {
    System.setOut(originalOut);
    System.setErr(originalErr);
  }

  @Test
  public void calculateAndValidateEndBalance_Valid_Scenario__Test() {
    Record test_record = new TestData.RecordBuilder().withStartBalance(TestData.START_BAL_TEST).withMutation(TestData.MUTATION_TEST)
        .withEndBalance(TestData.END_BAL_CORRECT_TEST).build();
    ValidationUtil.calculateAndValidateEndBalance(test_record);
    assertEquals(TestData.END_BALANCE_CALCULATION_IS_CORRECT, test_record.getStartBalance().add(test_record.getMutation()),
        test_record.getEndBalance());
  }

  @Test
  public void calculateAndValidateEndBalance_Invalid_Scenario__Test() {
    Record test_record = new TestData.RecordBuilder().withStartBalance(TestData.START_BAL_TEST).withMutation(TestData.MUTATION_TEST)
        .withEndBalance(TestData.END_BAL_INCORRECT_TEST).build();
    ValidationUtil.calculateAndValidateEndBalance(test_record);
    assertEquals(TestData.END_BALANCE_NOT_MATCHING, outContent.toString().trim());
  }

  @Test
  public void checkAmountFormat_Valid_Scenario__Test() {
    Record test_record = new TestData.RecordBuilder().withEndBalance(TestData.END_BAL_CORRECT_TEST).build();
    ValidationUtil.checkAmountFormat(test_record);
    assertEquals(TestData.END_BALANCE_FORMAT_IS_CORRECT, test_record.getEndBalance(), test_record.getEndBalance());
  }

  @Test
  public void checkAmountFormat_Invalid_Scenario__Test() {
    Record test_record = new TestData.RecordBuilder().withEndBalance(TestData.END_BAL_INCORRECT_FORMAT_TEST).build();
    ValidationUtil.checkAmountFormat(test_record);
    assertEquals(TestData.WRONG_END_BALANCE_FORMAT, outContent.toString().trim());
  }

  @Test
  public void checkUniqueness_Valid_Scenario__Test() {
    Map<Integer, String> refDescMapTest = new HashMap<>();
    refDescMapTest.put(1, "test");
    Record test_record = new TestData.RecordBuilder().withReference(TestData.REFERENCE_TEST).build();
    ValidationUtil.checkUniqueness(refDescMapTest, test_record);
    assertEquals(TestData.ALL_REFERENCE_ARE_UNIQUE, test_record.getReference(), test_record.getReference());
  }

  @Test
  public void checkUniqueness_Invalid_Scenario__Test() {
    Map<Integer, String> refDescMapTest = new HashMap<>();
    refDescMapTest.put(TestData.REFERENCE_TEST, "test");
    Record test_record = new TestData.RecordBuilder().withReference(TestData.REFERENCE_TEST).build();
    ValidationUtil.checkUniqueness(refDescMapTest, test_record);
    assertEquals(TestData.DUPLICATE_REFERENCE_NUMBER_DETECTED, outContent.toString().trim());
  }

}
