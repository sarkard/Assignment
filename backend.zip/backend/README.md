BACKEND INFORMATION   
===================

This is a stand alone java application, which will process two embedded xml and csv file after some validations, and print in correct record details in the console.


* [Java 8](http://www.oracle.com/technetwork/java/javase/downloads/index.html)
* [Maven](https://maven.apache.org/download.cgi) 

#Code formatter
Google java eclipse code formatter has been used for this project

 
## Future scope
In future we can implement a fully automated system which can read any files from any predefined folder in a particular time interval and process the data as required. Also it can send the error details in email if required.