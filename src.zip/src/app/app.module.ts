import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MatSortModule,MatTableModule, MatInputModule, MatFormFieldModule, } from '@angular/material';
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { UploadComponent }      from './upload/upload.component';

	

@NgModule({
  declarations: [
    AppComponent,
    UploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatSortModule,
    MatTableModule,
    NoopAnimationsModule,
    MatInputModule,
    MatFormFieldModule,
  ],
  exports: [
    MatSortModule,
    MatTableModule,
    NoopAnimationsModule,
    MatInputModule,
    MatFormFieldModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
