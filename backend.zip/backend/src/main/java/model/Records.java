package model;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This class represent the root level records object, it contains all the record
 * 
 * @author 472634
 *
 */
@XmlRootElement(name = "records")
public class Records {

  private List<Record> records = null;

  public List<Record> getRecords() {
    return records;
  }

  @XmlElement(name = "record")
  public void setRecords(List<Record> records) {
    this.records = records;
  }
}
