package validation;

import java.math.BigDecimal;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import model.Record;

/**
 * This class will used to validate data from xml and csv files
 * 
 * @author 472634
 *
 */
public class ValidationUtil {
  ValidationUtil() {

  }

  /**
   * This method will calculate the end balance from start balance and mutation, if any error found then print the details in console
   * 
   * @param eachRecord
   */
  public static void calculateAndValidateEndBalance(Record eachRecord) {
    if (eachRecord.getStartBalance() != null && eachRecord.getMutation() != null) {
      BigDecimal calculatedEB = eachRecord.getStartBalance().add(eachRecord.getMutation());
      if (eachRecord.getEndBalance().compareTo(calculatedEB) != 0) {
        System.out.println("End Balance not matching for Reference Number: " + eachRecord.getReference() + " and Description: "
            + eachRecord.getDescription());
      }
    }
  }

  /**
   * This will check basic amount formating
   * 
   * @param eachRecord
   */
  public static void checkAmountFormat(Record eachRecord) {
    final String regExp = "[0-9-]+([,.][0-9]{1,2})?";
    final Pattern pattern = Pattern.compile(regExp);
    Matcher matcher = pattern.matcher(eachRecord.getEndBalance().toString());
    if (!matcher.matches()) {
      System.out.println("Wrong End Balance format: " + eachRecord.getEndBalance() + " Reference Number: " + eachRecord.getReference()
          + " and Description: " + eachRecord.getDescription());
    }
  }

  /**
   * This will check for duplicate records, if duplicate found it will print the details in console
   * 
   * @param refDescMap
   * @param eachRecord
   */
  public static void checkUniqueness(Map<Integer, String> refDescMap, Record eachRecord) {
    if (!refDescMap.containsKey(eachRecord.getReference())) {
      refDescMap.put(eachRecord.getReference(), eachRecord.getDescription());
    } else {
      System.out.println(
          "Duplicate Reference Number detected: " + eachRecord.getReference() + " and Description: " + eachRecord.getDescription());
    }
  }

}
