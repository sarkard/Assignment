package main;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import model.Record;
import model.Records;
import validation.ValidationUtil;

/**
 * This class will process xml and csv files after validations. It will print the error record details in console.
 * 
 * @author 472634
 *
 */
public class ReadData {

  private static final String REFERENCE = "Reference";

  public static void main(String[] args) throws JAXBException, IOException, URISyntaxException {
    xmlFileProcessing();
    csvFileProcessing();
  }

  /**
   * This method will process the xml file and print the error report in console
   * 
   * @throws JAXBException
   */
  private static void xmlFileProcessing() throws JAXBException {
    System.out.println(":::XML ERROR RECORDS:::");
    String fileName = "xml/records.xml";
    ClassLoader classLoader = ReadData.class.getClassLoader();
    File file = new File(classLoader.getResource(fileName).getFile());
    JAXBContext jaxbContext = JAXBContext.newInstance(Records.class);
    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
    Records records = (Records) unmarshaller.unmarshal(file);
    Map<Integer, String> refDescXmlMap = new HashMap<Integer, String>();
    for (Record eachRecord : records.getRecords()) {
      validations(refDescXmlMap, eachRecord);

    }
  }

  /**
   * This method will process the csv file and print the error report in console
   * 
   * @throws URISyntaxException
   * @throws IOException
   */
  private static void csvFileProcessing() throws URISyntaxException, IOException {
    System.out.println(":::CSV ERROR RECORDS:::");
    URI uri = ClassLoader.getSystemResource("csv/records.csv").toURI();
    String mainPath = Paths.get(uri).toString();
    Path path = Paths.get(mainPath);
    Reader reader = Files.newBufferedReader(path);
    CSVParser parser = new CSVParserBuilder().withSeparator(',').withIgnoreQuotations(true).build();
    CSVReader csvReader = new CSVReaderBuilder(reader).withSkipLines(0).withCSVParser(parser).build();
    List<String[]> list = csvReader.readAll();
    reader.close();
    csvReader.close();
    Map<Integer, String> refDescCsvMap = new HashMap<Integer, String>();
    for (String[] each : list) {
      if (!REFERENCE.equalsIgnoreCase(each[0])) {
        Record eachRecord = new Record(each);
        validations(refDescCsvMap, eachRecord);
      }
    }
  }

  /**
   * This is a common validation method for both xml and csv files data
   * 
   * @param refDescMap
   * @param eachRecord
   */
  private static void validations(Map<Integer, String> refDescMap, Record eachRecord) {
    ValidationUtil.checkUniqueness(refDescMap, eachRecord);

    if (eachRecord.getEndBalance() != null) {
      ValidationUtil.checkAmountFormat(eachRecord);
      ValidationUtil.calculateAndValidateEndBalance(eachRecord);
    }
  }



}
